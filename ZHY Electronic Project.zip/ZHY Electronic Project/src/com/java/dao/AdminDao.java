package com.java.dao;

import com.java.model.Admin;

public interface AdminDao {
	
	public Admin login(Admin admin);
	
}
